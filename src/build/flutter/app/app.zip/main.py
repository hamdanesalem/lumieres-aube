import flet as ft
import requests
import math
import json
import os
from datetime import datetime, timedelta

CONFIG_FILE = "config.json"

def load_saved_state():
    """Charge les données sauvegardées depuis le fichier JSON local"""
    default_state = {
        "city": "Annaba",
        "country": "Algérie",
        "lat": 36.905,
        "lon": 7.755
    }
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            return default_state
    return default_state

def save_state_to_file(name, country, lat, lon):
    """Sauvegarde les données dans le fichier JSON local"""
    data = {
        "city": name,
        "country": country,
        "lat": lat,
        "lon": lon
    }
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    except:
        pass

def search_city_coords(city_name):
    try:
        url = f"https://geocoding-api.open-meteo.com/v1/search?name={city_name}&count=1&language=fr"
        r = requests.get(url, timeout=5).json()
        results = r.get("results", [])
        if results:
            res = results[0]
            country_res = res.get("country", "Algérie")
            if country_res.lower() in ["algeria", "algerie"]:
                country_res = "Algérie"
            return res.get("name"), float(res.get("latitude")), float(res.get("longitude")), country_res
    except:
        pass
    return None, None, None, None

def calc_dawn_time(lat, lon, date, angle):
    day_of_year = date.timetuple().tm_yday
    declination = 0.4093 * math.sin(2 * math.pi * (284 + day_of_year) / 365)
    lat_rad = math.radians(lat)
    angle_rad = math.radians(angle)
    
    try:
        cos_H = (math.sin(angle_rad) - math.sin(lat_rad) * math.sin(declination)) / (math.cos(lat_rad) * math.cos(declination))
        if cos_H > 1 or cos_H < -1:
            return None
        H = math.degrees(math.acos(cos_H))
    except:
        return None

    solar_noon = 12.0 - (lon - 15.0) / 15.0 
    dawn_hours = solar_noon - (H / 15.0)
    
    b = 2 * math.pi * (day_of_year - 81) / 364
    eot = 9.87 * math.sin(2 * b) - 7.53 * math.cos(b) - 1.5 * math.sin(b)
    dawn_hours -= (eot / 60.0)

    hour = int(dawn_hours)
    minute = int((dawn_hours - hour) * 60)
    return datetime(date.year, date.month, date.day, hour, minute)

def main(page: ft.Page):
    page.title = "Lumières de l'Aube"
    page.window.width = 360
    page.window.height = 690
    page.window.resizable = False
    page.bgcolor = "#1A2639"
    page.theme_mode = ft.ThemeMode.DARK
    page.safe_area = True
    page.padding = ft.Padding.symmetric(horizontal=12, vertical=8)
    page.spacing = 0
    page.vertical_alignment = ft.MainAxisAlignment.START
    page.horizontal_alignment = ft.CrossAxisAlignment.STRETCH

    saved = load_saved_state()

    state = {
        "lang": "FR", 
        "city": saved["city"], 
        "country": saved["country"],
        "lat": saved["lat"], 
        "lon": saved["lon"], 
        "date": datetime.now()
    }

    TRAD = {
        "FR": {
            "title": "Lumières de l'Aube", "choose_date": "Choisir une date :",
            "h18": "Fausse Aube (-18°)", "h15": "Fil de Lumière (-15°)", "h12": "Aube Nautique (-12°)",
            "wait": "Attente : + ", "min": " min", "gps": "GPS Auto",
            "f1": "1. -18° : Lumière verticale (Fajr Kadhib).",
            "f2": "2. -15° : Premier trait horizontal net sur la mer.",
            "f3": "3. -12° : L'horizon devient visible et clair.",
            "search_hint": "Autre ville... (ex: Oran, Merahna)"
        },
        "ARA": {
            "title": "أضواء الفجر", "choose_date": "اختر التاريخ:",
            "h18": "الفجر الكاذب (-18°)", "h15": "خيط الضوء الأول (-15°)", "h12": "الفجر الملاحي (-12°)",
            "wait": "الانتظار: + ", "min": " دقيقة", "gps": "تحديد تلقائي",
            "f1": "1. -18 درجة: ضوء عمودي (الفجر الكاذب).",
            "f2": "2. -15 درجة: أول خيط أفقي فوق البحر.",
            "f3": "3. -12 درجة: وضوح الأفق تماماً.",
            "search_hint": "مدينة أخرى... (مثال: وهران)"
        },
        "EN": {
            "title": "Lights of Dawn", "choose_date": "Choose a date:",
            "h18": "False Dawn (-18°)", "h15": "Thread of Light (-15°)", "h12": "Nautical Dawn (-12°)",
            "wait": "Waiting: + ", "min": " min", "gps": "Auto GPS",
            "f1": "1. -18°: Vertical light (Fajr Kadhib).",
            "f2": "2. -15°: First sharp horizontal line over the sea.",
            "f3": "3. -12°: Horizon becomes clear and visible.",
            "search_hint": "Other city... (e.g. Oran, Merahna)"
        }
    }

    txt_main_title = ft.Text("", size=22, weight="bold", color="#4A90E2")
    txt_location = ft.Text("", size=13, color="#8F9BB3")
    txt_choose = ft.Text("", size=13, color="white")
    txt_date_display = ft.Text("", size=16, weight="bold", color="white")
    
    btn_gps = ft.FilledButton("", icon=ft.Icons.MY_LOCATION, on_click=lambda e: sync_gps(e))
    timeline_container = ft.Column(spacing=8)
    
    footer_text1 = ft.Text("", size=11, color="#8F9BB3")
    footer_text2 = ft.Text("", size=11, color="#8F9BB3")
    footer_text3 = ft.Text("", size=11, color="#8F9BB3")

    # Utilisation d'indicateurs textuels universels stables sur PC et parfaits sur Android
    lang_dropdown = ft.Dropdown(
        width=170,
        text_size=12,
        color="white",
        filled=True,
        fill_color="#161F30",
        border_color="#314563",
        value=state["lang"],
        options=[
            ft.DropdownOption(key="FR", text="Français (FR)"),
            ft.DropdownOption(key="ARA", text="العربية (DZ)"),
            ft.DropdownOption(key="EN", text="English (EN)"),
        ],
    )

    input_search = ft.TextField(
        hint_text="",
        height=44,
        text_size=12,
        color="white",
        expand=True,
        on_submit=lambda e: run_search(e),
    )
    btn_search = ft.IconButton(ft.Icons.SEARCH, icon_color="#4A90E2", on_click=lambda e: run_search(e))

    def build_timeline_item(title, time_str, wait_str, is_first=False):
        return ft.Row([
            ft.Container(width=4, height=50, bgcolor="#4A90E2" if not is_first else "transparent"),
            ft.Container(width=10, height=10, border_radius=5, bgcolor="#4A90E2"),
            ft.Column([
                ft.Text(title, size=12, color="#8F9BB3"),
                ft.Text(time_str, size=20, weight="bold", color="white"),
                ft.Text(wait_str, size=11, color="#FF6B4A", weight="bold") if wait_str else ft.Container()
            ], spacing=1)
        ], alignment="start")

    def update_ui():
        L = TRAD[state["lang"]]

        lang_dropdown.value = state["lang"]
        input_search.hint_text = L["search_hint"]
        txt_main_title.value = L["title"]
        txt_location.value = f"{state['city']}, {state['country']}"
        
        txt_choose.value = L["choose_date"]
        txt_date_display.value = state["date"].strftime("%d / %m / %Y")
        btn_gps.text = L["gps"]
        
        footer_text1.value = L["f1"]
        footer_text2.value = L["f2"]
        footer_text3.value = L["f3"]

        dt18 = calc_dawn_time(state["lat"], state["lon"], state["date"], -18.0)
        dt15 = calc_dawn_time(state["lat"], state["lon"], state["date"], -15.0)
        dt12 = calc_dawn_time(state["lat"], state["lon"], state["date"], -12.0)

        t18_str = dt18.strftime("%H:%M") if dt18 else "--:--"
        t15_str = dt12_str = ""
        wait_15 = wait_12 = ""

        if dt18 and dt15:
            t15_str = dt15.strftime("%H:%M")
            diff15 = int((dt15 - dt18).total_seconds() / 60)
            wait_15 = f"{L['wait']}{diff15}{L['min']}"

        if dt15 and dt12:
            dt12_str = dt12.strftime("%H:%M")
            diff12 = int((dt12 - dt15).total_seconds() / 60)
            wait_12 = f"{L['wait']}{diff12}{L['min']}"

        timeline_container.controls.clear()
        timeline_container.controls.extend([
            build_timeline_item(L["h18"], t18_str, "", is_first=True),
            build_timeline_item(L["h15"], t15_str, wait_15),
            build_timeline_item(L["h12"], dt12_str, wait_12)
        ])
        page.update()

    def set_lang(lang_code):
        state["lang"] = lang_code
        update_ui()

    def on_lang_select(e):
        if e.control.value:
            set_lang(e.control.value)

    lang_dropdown.on_select = on_lang_select

    def run_search(e):
        val = input_search.value.strip()
        if not val:
            return
        
        txt_location.value = "[ Recherche en cours... ]" if state["lang"] != "ARA" else "[ جاري البحث... ]"
        page.update()
        
        name, lat, lon, country = search_city_coords(val)
        if name and lat and lon:
            state.update({
                "city": name,
                "country": country,
                "lat": lat,
                "lon": lon
            })
            save_state_to_file(name, country, lat, lon)
            input_search.value = ""
        else:
            txt_location.value = "Introuvable" if state["lang"] != "ARA" else "لم يتم العثور عليها"
            page.update()
            return
        update_ui()

    def change_day(delta):
        state["date"] += timedelta(days=delta)
        update_ui()

    def sync_gps(e):
        txt_location.value = "[ Recherche GPS... ]" if state["lang"] != "ARA" else "[ جاري البحث... ]"
        page.update()

        try:
            # Requête vers un résolveur IP direct et robuste
            r = requests.get("http://ip-api.com/json/", timeout=4).json()
            if r.get("status") == "success":
                lat = float(r.get("lat"))
                lon = float(r.get("lon"))
                city = r.get("city") or "Annaba"
                country = r.get("country") or "Algérie"
                
                if country.lower() in ["algeria", "algerie"]:
                    country = "Algérie"

                state.update({
                    "city": city,
                    "country": country,
                    "lat": lat,
                    "lon": lon,
                })
                save_state_to_file(city, country, lat, lon)
                input_search.value = ""
            else:
                raise Exception()
        except:
            # En cas d'échec internet total, on force l'actualisation sur Annaba
            state.update({
                "city": "Annaba",
                "country": "Algérie",
                "lat": 36.905,
                "lon": 7.755,
            })
            save_state_to_file("Annaba", "Algérie", 36.905, 7.755)
            input_search.value = ""
            
        update_ui()

    header_section = ft.Column(
        [
            ft.Row(
                [lang_dropdown, btn_gps],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            ),
            ft.Row(
                [input_search, btn_search],
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=8,
            ),
            ft.Column(
                [txt_main_title, txt_location],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=4,
            ),
        ],
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=10,
    )

    timeline_panel = ft.Container(
        content=ft.Column(
            [
                txt_choose,
                ft.Row(
                    [
                        ft.IconButton(
                            ft.Icons.KEYBOARD_ARROW_LEFT,
                            on_click=lambda _: change_day(-1),
                            icon_color="#4A90E2",
                        ),
                        txt_date_display,
                        ft.IconButton(
                            ft.Icons.KEYBOARD_ARROW_RIGHT,
                            on_click=lambda _: change_day(1),
                            icon_color="#4A90E2",
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=10,
                ),
                ft.Divider(height=8, color="#232D3B"),
                timeline_container,
            ],
            spacing=10,
            expand=True,
            alignment=ft.MainAxisAlignment.CENTER,
        ),
        padding=16,
        bgcolor="#161F30",
        border_radius=12,
        expand=True,
    )

    footer_section = ft.Container(
        content=ft.Column([footer_text1, footer_text2, footer_text3], spacing=4),
        padding=12,
        bgcolor="#0E1624",
        border_radius=10,
    )

    page.add(
        ft.SafeArea(
            expand=True,
            content=ft.Column(
                [header_section, timeline_panel, footer_section],
                expand=True,
                spacing=10,
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            ),
        )
    )
    update_ui()

if __name__ == "__main__":
    ft.run(main)